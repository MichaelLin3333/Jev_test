"""Paired scores, intermediate judgments, token lengths and readable examples."""
from collections import Counter
import csv
import json
import numpy as np
from .lab import ROOT, ARMS, read, save, now, verify

def percentage(value):
    return "n/a" if value is None else f"{100*value:.1f}%"

def number(value):
    return "n/a" if value is None else f"{value:.4f}"

def paired(reference,variant,cases):
    ref = {row["case_id"]:row for row in reference["rows"]}
    months = {case["case_id"]:case["decision_time"][:7] for case in cases}
    blocks = {}
    fixed = worsened = 0
    rows = []
    for row in variant["rows"]:
        old = ref[row["case_id"]]
        if row["actual"] not in ("up","flat","down"):
            continue
        correct = row["correct"] is True
        was_correct = old["correct"] is True
        fixed += correct and not was_correct
        worsened += was_correct and not correct
        delta = (int(correct)-int(was_correct),(row["brier"] if row["brier"] is not None else 2.)-(old["brier"] if old["brier"] is not None else 2.))
        blocks.setdefault(months[row["case_id"]],[]).append(delta)
        rows.append({"case_id":row["case_id"],"actual":row["actual"],"reference_prediction":old["prediction"],"variant_prediction":row["prediction"],"accuracy_change":delta[0],"brier_change":delta[1]})
    groups = list(blocks.values())
    rng = np.random.default_rng(2718)
    draws = []
    for _ in range(5000):
        sample = [value for index in rng.integers(0,len(groups),len(groups)) for value in groups[index]]
        draws.append(np.mean(sample,axis=0))
    intervals = np.quantile(draws,[.025,.975],axis=0)
    return {"fixed":int(fixed),"new_errors":int(worsened),"month_blocks":len(groups),"accuracy_change":float(np.mean([row["accuracy_change"] for row in rows])),"brier_change":float(np.mean([row["brier_change"] for row in rows])),"accuracy_change_95_interval":intervals[:,0].tolist(),"brier_change_95_interval":intervals[:,1].tolist(),"rows":rows}

def stage_summary(records,cases):
    by_id = {case["case_id"]:case for case in cases}
    successful = {cid:value["assessments"] for cid,value in records.items() if value.get("assessments")}
    result = {"completed_business_stages":len(successful)}
    for question in ("revenue","cash","surprise"):
        result[question] = dict(Counter(value[question]["choice"] for value in successful.values()))
    for name,ids in (("issuer",[cid for cid in successful if not by_id[cid]["control"]]),("unrelated_controls",[cid for cid in successful if by_id[cid]["control"]])):
        result[name] = {"n":len(ids),"relevance_yes_at_least_half":sum(successful[cid]["relevance"]["noul"]>=.5 for cid in ids),"mean_relevance":float(np.mean([successful[cid]["relevance"]["noul"] for cid in ids])) if ids else None}
    return result

def trace(cid,records):
    lines = [f"# Paired input trace: {cid}","","Complete saved input payloads and returned JSON responses, without omissions. Formatting is pretty-printed JSON. Outcomes are shown separately at the end and were outside all requests.",""]
    for arm in ARMS:
        lines += ["## "+arm,""]
        for index,key in enumerate(records[arm][cid]["requests"],1):
            value = read(ROOT / "records" / "api_cache" / (key+".json"))
            lines += [f"### Stage {index}: complete input","","```json",json.dumps(value["request"],ensure_ascii=False,indent=2),"```","",f"### Stage {index}: complete output","","```json",json.dumps(value.get("response",{"status":value["status"],"attempts":value["attempts"]}),ensure_ascii=False,indent=2),"```",""]
    lines += ["## Outcome, evaluator only","","```json",json.dumps(read(ROOT / "data" / "outcomes.json")[cid],ensure_ascii=False,indent=2),"```",""]
    path = ROOT / "examples" / (cid+"_full_trace.md")
    path.write_text("\n".join(lines),encoding="utf-8")

def report():
    audit = verify()
    cases = read(ROOT / "data" / "cases.json")
    scores = read(ROOT / "records" / "scores.json")["scores"]
    records = {arm:read(ROOT / "records" / (arm+"_records.json")) for arm in ARMS}
    comparisons = {arm:paired(scores["raw_json"]["all150"],scores[arm]["all150"],cases) for arm in ARMS[1:]}
    stages = {arm:stage_summary(values,cases) for arm,values in records.items()}
    tokens = {}
    for arm,values in records.items():
        per_stage = {1:[],2:[]}
        for value in values.values():
            for index,key in enumerate(value["requests"],1):
                cache = read(ROOT / "records" / "api_cache" / (key+".json"))
                if cache["status"]=="ok":
                    per_stage[index].append(cache["response"]["usage"]["input_tokens"])
        tokens[arm] = {str(stage):{"requests":len(lengths),"mean":float(np.mean(lengths)) if lengths else None,"min":min(lengths) if lengths else None,"max":max(lengths) if lengths else None} for stage,lengths in per_stage.items()}
    save(ROOT / "records" / "paired_comparisons.json",comparisons)
    save(ROOT / "records" / "intermediate_summary.json",stages)
    save(ROOT / "records" / "token_lengths.json",tokens)
    lines = ["# Jev input representation: percentages and summarized prose","",f"Completed {now()}. Model pinned to jev-1.13.0. One reference and exactly two requested representation variants; no tuning after scores.","","## Interpretation","","The same 150 cases from the latest run were reused: 120 earlier development cases plus 30 January-June 2026 cases. All outcomes had previously been examined. This is a paired development/regression comparison, not an independent final test. The one original split-window exclusion remains, so 149 price labels are scored. No new prices, article research, statistical model fitting or downstream model selection occurred.","","Every arm uses the same two-stage business_then_trade question sequence: six business questions together, then one forecast using those answers. The reference reuses the earlier 120 completed staged records and completes the missing 30. The saved single-call method is an additional comparison, not the paired reference for these transformations.","","## Results on the same 150 scheduled cases","","| Method | Correct / labeled | Accuracy | Balanced accuracy | Brier (lower better) | Forecast coverage |","|---|---:|---:|---:|---:|---:|"]
    csv_rows = []
    for arm,value in scores.items():
        metric = value["all150"]
        lines.append(f"| {arm} | {metric['correct']}/{metric['labeled']} | {percentage(metric['full_coverage_accuracy'])} | {percentage(metric['balanced_accuracy'])} | {number(metric['brier'])} | {percentage(metric['forecast_coverage'])} |")
        csv_rows.append({"method":arm,"correct":metric["correct"],"labeled":metric["labeled"],"accuracy":metric["full_coverage_accuracy"],"balanced_accuracy":metric["balanced_accuracy"],"brier":metric["brier"],"forecast_coverage":metric["forecast_coverage"]})
    with (ROOT / "results.csv").open("w",encoding="utf-8",newline="") as stream:
        writer = csv.DictWriter(stream,fieldnames=list(csv_rows[0]))
        writer.writeheader()
        writer.writerows(csv_rows)
    lines += ["","Missing forecasts count wrong for accuracy and incur maximum Brier 2 for paired deltas. Brier in the table is the mean on covered cases; coverage is shown alongside it.","","## Paired changes relative to the raw JSON staged method",""]
    for arm,value in comparisons.items():
        lines += [f"**{arm}**: {value['fixed']} corrected cases, {value['new_errors']} new errors. Accuracy change {100*value['accuracy_change']:+.1f} percentage points; Brier change {value['brier_change']:+.4f}. Negative Brier change is better. Month-block bootstrap 95% intervals: accuracy {percentage(value['accuracy_change_95_interval'][0])} to {percentage(value['accuracy_change_95_interval'][1])}; Brier {number(value['brier_change_95_interval'][0])} to {number(value['brier_change_95_interval'][1])}. There are {value['month_blocks']} month blocks; shared market dependence and prior development exposure remain.",""]
    best_baseline = max(scores[name]["all150"]["full_coverage_accuracy"] for name in ("always_up","market_only","training_prior"))
    for arm in ARMS[1:]:
        metric = scores[arm]["all150"]
        lines += [f"{arm}: {'higher' if metric['full_coverage_accuracy']>scores['raw_json']['all150']['full_coverage_accuracy'] else 'no higher'} observed accuracy than the paired raw staged reference; {'higher' if metric['full_coverage_accuracy']>best_baseline else 'no higher'} accuracy than the strongest fixed non-Jev baseline. The 70% goal was {'reached' if metric['full_coverage_accuracy']>=.70 and metric['forecast_coverage']==1 else 'not reached'}.",""]
    lines += ["## Results by original period","","These are historical group names, not fresh train/validation/test roles for this comparison.","","| Arm | Original group | Correct / labeled | Accuracy | Brier | Coverage |","|---|---|---:|---:|---:|---:|"]
    for arm in ARMS:
        for group,metric in scores[arm].items():
            if group!="all150":
                lines.append(f"| {arm} | {group} | {metric['correct']}/{metric['labeled']} | {percentage(metric['full_coverage_accuracy'])} | {number(metric['brier'])} | {percentage(metric['forecast_coverage'])} |")
    lines += ["","## Did the earlier business answers change?","","| Arm | Business stages | Revenue choices | Cash choices | Surprise choices | Issuer relevance >=50% | Controls relevance >=50% |","|---|---:|---|---|---|---:|---:|"]
    for arm,value in stages.items():
        issuer,controls=value["issuer"],value["unrelated_controls"]
        lines.append(f"| {arm} | {value['completed_business_stages']} | {value['revenue']} | {value['cash']} | {value['surprise']} | {issuer['relevance_yes_at_least_half']}/{issuer['n']} | {controls['relevance_yes_at_least_half']}/{controls['n']} |")
    lines += ["","These are behavior distributions, not an adjudicated overall semantic-accuracy score. Missing analyst consensus supports unknown surprise. Unrelated NASA controls should not establish target revenue/cash effects. Direct issuer relevance is a useful sanity screen; it is not a substitute for reviewing every business judgment.","","## What exactly changed","","- raw_json: original full source excerpts, long decimal market values and prior answers in nested JSON.","- percent_descriptions: same passages and structure, returns/volatility shown to two percentage decimals, probabilities to four percentage decimals, short descriptions and explicit units; equivalent target thresholds in the question expressed as percentages. Absolute currency amounts, counts and publication dates are preserved.","- summarized_prose: a natural-language state with an incomplete source-sentence summary, the company/cutoff/target, all ten pre-cutoff market observations and reference probabilities, followed by attributed natural-language earlier judgments. All alternatives and confidence are preserved as percentages. Unknown is explicitly not no effect or flat.","","The prose arm bundles summarization, state shortening, percentage representation, code-computed trend wording and formatting. It cannot establish that JSON punctuation alone caused any change. The source summary uses actual selected source sentences, not a generative rewrite: this avoids introducing fabricated facts but can omit important qualifications or numbers. Every selected sentence and omitted numerical token is saved in data/representation_summaries.json. API transport and returned answers remain JSON; the prose state itself is a plain string.","","No summary saw an outcome, correctness flag, future return or exit price. Simple descriptions such as rose/fell/outperformed were calculated from already-saved pre-cutoff values. Historical source-version uncertainty and missing expectations remain explicit. Earlier Jev judgments remain uncertain model judgments, never asserted as established financial facts.","","## Input lengths","","| Arm | Mean stage-1 input tokens | Mean stage-2 input tokens |","|---|---:|---:|"]
    for arm,value in tokens.items():
        lines.append(f"| {arm} | {value['1']['mean']:.0f} | {value['2']['mean']:.0f} |")
    lines += ["","Token lengths are reported from accepted API responses; this experiment changes both length and representation, so it is not a pure context-length intervention.","","## Full paired example and errors",""]
    cid = "AAPL-2025-02-21-216bbb1456"
    trace(cid,records)
    outcome=read(ROOT / "data" / "outcomes.json")[cid]
    lines += [f"The previously discussed Apple News+ Food case: actual {outcome['label']}, raw return {100*outcome['return']:.4f}%. Full inputs and outputs for every arm/stage are in [the paired trace](representation_example_{cid}_full_trace.md).",""]
    for arm in ARMS:
        lines.append(f"- {arm}: {records[arm][cid]['probabilities']}.")
    lines += ["","Confident wrong forecasts (up to three per arm):",""]
    for arm in ARMS:
        errors=sorted((row for row in scores[arm]["all150"]["rows"] if row["correct"] is False),key=lambda row:row["brier"],reverse=True)[:3]
        for row in errors:
            lines.append(f"- {arm}, {row['case_id']}: predicted {row['prediction']}, actual {row['actual']}; probabilities {row['probabilities']}.")
    lines += ["","## Coverage, failures and checks","",f"{audit['unique_api_requests']} unique cached API requests, of which {audit['reused_requests']} were reused from the preceding run. Saved records contain {audit['rejected_attempts']} rejected attempts and {audit['exhausted_requests']} exhausted requests. All attempts remain, including failures. {audit['earlier_files_checked']} earlier files were hash-checked with zero changes. Replaying the evaluator reproduced the scores. The frozen protocol/input/code manifest is in frozen/representation_inputs.json; environment versions are recorded.","","Response/schema validation and identical-request retry rules were frozen before calls. There was no retry based on correctness, no case replacement, and no post-score prompt or summary optimization. Response coverage is valid forecast count / scheduled cases; label coverage separately tracks usable prices. Full-coverage accuracy counts missing forecasts wrong. Confusion matrices, per-case scores and separate max-probability>=0.60 selective coverage/accuracy are in records/representation_scores.json.","","## Reproduction","","Run from the repository root:","","```powershell","python -B jev_benchmark_lab/question_search_10/representation_run.pyw test","python -B jev_benchmark_lab/question_search_10/representation_run.pyw verify","python -B jev_benchmark_lab/question_search_10/representation_run.pyw report","```","","A new run follows prepare -> test -> smoke -> run -> report. This completed run refuses another prediction round after scores.json exists; verification and report reproduction use saved results without API calls. Modify a copied experiment folder and freeze a new version for a later comparison.","","Main functions: render.numeric_state converts only known ratios/probabilities into described percentages; render.source_summary selects source sentences with saved provenance; render.prose_state assembles natural language and summarizes prior answers; lab.one_case runs the two calls; lab.score reuses the unchanged evaluator; report.paired compares the same events. No statistical coefficients or Jev weights were trained.",""]
    (ROOT / "REPORT.md").write_text("\n".join(lines),encoding="utf-8")
    print("REPORT",str(ROOT / "REPORT.md"),flush=True)
