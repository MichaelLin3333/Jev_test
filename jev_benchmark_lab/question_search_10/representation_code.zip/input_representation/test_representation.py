"""Presentation checks without API calls."""
import copy
import unittest
from .lab import ROOT, PRIOR, read, digest, score
from .render import numeric_state, described_prior, source_summary, prose_state, rate_questions, market_sentence

def example():
    path = PRIOR / "records" / "api_cache" / "b7286a494eae099312046728fb56d633bb5585ea366442c205b4f6ed28b5d949.json"
    return read(path)

class RepresentationTests(unittest.TestCase):
    def test_percent_units_and_negative_sign(self):
        self.assertIn("fell 1.61%",market_sentence("spy_return_20",-.016088556881662552))
        self.assertIn("11.40 percentage points",market_sentence("relative_return_20",.11396032220059016))
        self.assertIn("not expected appreciation",market_sentence("stock_volatility_20",.0171))

    def test_numbers_only_preserves_sources_and_dates(self):
        original = example()["request"]["state"]
        before = digest(original)
        value = numeric_state(original)
        self.assertEqual(value["articles"],original["articles"])
        self.assertEqual(value["company"],original["company"])
        self.assertEqual(value["decision_time"],original["decision_time"])
        self.assertIn("65.1672%",value["base_forecast"]["probabilities"]["up"])
        self.assertEqual(digest(original),before)

    def test_prior_unknown_remains_unknown_and_attributed(self):
        saved = example()
        result = described_prior(saved["request"]["questions"],saved["response"])
        self.assertEqual(result["revenue"]["answer"]["choice"],"unknown")
        self.assertIn("81.0000%",result["revenue"]["answer"]["probabilities"]["unknown"])
        self.assertIn("not a stock-return probability",result["relevance"]["answer"]["noul"])

    def test_prose_does_not_misstate_model_judgments_as_facts(self):
        saved = example()
        state = saved["request"]["state"]
        summaries = [source_summary(article["text"],article["title"]) for article in state["articles"]]
        result = prose_state(state,summaries,saved["response"])
        self.assertIsInstance(result,str)
        self.assertIn("uncertain model assessments, not verified facts",result)
        self.assertIn("selected unknown",result)
        self.assertIn("not no effect",result)
        self.assertNotIn('"probabilities":',result)
        self.assertIn("market",result)

    def test_summary_adds_no_source_sentences(self):
        text = "Apple announced a new service. Revenue increased 12.5% to $15 billion. It will launch in April. Copyright all rights reserved."
        result = source_summary(text,"Apple new service")
        self.assertTrue(all(row["text"] in text for row in result["selected_sentences"]))
        self.assertIn("12.5%",result["text"])
        self.assertNotIn("Copyright",result["text"])

    def test_abbreviations_do_not_create_fragments(self):
        text = 'The company announced results. Dr. Lisa Su said revenue increased 10%. The call starts at 2:00 p.m. ET today.'
        result = source_summary(text,"company results")
        self.assertIn("Dr. Lisa Su",result["text"])
        self.assertIn("2:00 p.m. ET",result["text"])
        self.assertFalse(any(row["text"].endswith("Dr.") or row["text"].endswith("p.m.") for row in result["selected_sentences"]))

    def test_equivalent_return_thresholds_preserve_options(self):
        question = {"forecast":{"instructions":"Forecast return.","type":"choice","criteria":{"up":"Return exceeds +0.01.","flat":"Return is between -0.01 and +0.01.","down":"Return is below -0.01."}}}
        new = rate_questions(question)
        self.assertEqual(list(new["forecast"]["criteria"]),["up","flat","down"])
        self.assertIn("+1.00%",new["forecast"]["criteria"]["up"])
        self.assertIn("-1.00%",new["forecast"]["criteria"]["down"])
        self.assertIn("+0.01",question["forecast"]["criteria"]["up"])

    def test_missing_forecasts_do_not_raise_reported_accuracy(self):
        value = score(["a","b"],{"a":{"up":1.,"flat":0.,"down":0.}}, {"a":{"label":"up"},"b":{"label":"down"}})
        self.assertEqual(value["full_coverage_accuracy"],.5)
        self.assertEqual(value["forecast_coverage"],.5)

    def test_model_output_numeric_values_unchanged(self):
        saved = example()
        before = copy.deepcopy(saved["response"])
        described_prior(saved["request"]["questions"],saved["response"])
        self.assertEqual(saved["response"],before)

if __name__ == "__main__":
    unittest.main()
