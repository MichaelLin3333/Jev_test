"""Keep new records in existing folders, with a distinct filename prefix."""
from pathlib import Path

class StorePath:
    def __init__(self, root, parts=()):
        self.root = Path(root)
        self.parts = tuple(parts)

    def __truediv__(self, part):
        return StorePath(self.root,self.parts+(str(part),))

    @property
    def parent(self):
        return StorePath(self.root,self.parts[:-1])

    @property
    def name(self):
        return self.parts[-1]

    @property
    def stem(self):
        return Path(self.name).stem

    def directory(self):
        parts = self.parts
        if not parts:
            return self.root,"representation_"
        if parts in (("data",),("frozen",),("records",)):
            return self.root.joinpath(*parts),"representation_"
        if parts == ("records","api_cache"):
            return self.root/"records","representation_api_"
        if parts == ("records","reused"):
            return self.root/"records","representation_reused_"
        if len(parts)==3 and parts[:2]==("records","cases"):
            return self.root/"records"/"predictions"/"iteration_02","representation_"+parts[2]+"_"
        if parts == ("examples",):
            return self.root,"representation_example_"
        raise ValueError("Unsupported storage location: "+str(parts))

    def physical(self):
        folder,prefix = self.parent.directory()
        assert folder.is_dir(), "Existing folder required: "+str(folder)
        if self.parts == ("REPORT.md",):
            return folder/"REPRESENTATION_REPORT.md"
        return folder/(prefix+self.name)

    def __fspath__(self):
        return str(self.physical())

    def __str__(self):
        return str(self.physical()) if self.parts else str(self.root)

    def mkdir(self,parents=False,exist_ok=False):
        folder,_=self.directory()
        assert folder.is_dir(), "No new folders are created: "+str(folder)

    def exists(self):
        return self.physical().exists()

    def read_bytes(self):
        return self.physical().read_bytes()

    def write_bytes(self,value):
        return self.physical().write_bytes(value)

    def read_text(self,**kwargs):
        return self.physical().read_text(**kwargs)

    def write_text(self,value,**kwargs):
        return self.physical().write_text(value,**kwargs)

    def open(self,*args,**kwargs):
        return self.physical().open(*args,**kwargs)

    def glob(self,pattern):
        folder,prefix=self.directory()
        return [StorePath(self.root,self.parts+(path.name[len(prefix):],)) for path in folder.glob(prefix+pattern)]
