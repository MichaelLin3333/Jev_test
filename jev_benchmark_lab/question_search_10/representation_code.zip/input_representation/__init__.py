"""Paired tests of percentage descriptions and summarized prose."""
