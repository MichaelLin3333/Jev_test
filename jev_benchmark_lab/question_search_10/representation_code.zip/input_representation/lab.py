"""A frozen, three-arm, paired comparison of Jev input presentation."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import Counter
import argparse
import copy
import csv
import hashlib
import importlib.metadata
import json
import shutil
import sys
import numpy as np
from jev_benchmark_lab import common, strategy, evaluate
from .render import numeric_state, described_prior, source_summary, prose_state, rate_questions
from .storage import StorePath

EXISTING = Path(sys.argv[0]).resolve().parent
ROOT = StorePath(EXISTING)
OLD = EXISTING.parent
PRIOR = EXISTING
REPO = OLD.parent
common.ROOT = ROOT
strategy.ROOT = ROOT
read, save, digest, now = common.read, common.save, common.digest, common.now
ARMS = ("raw_json", "percent_descriptions", "summarized_prose")

def hashes():
    return {name:hashlib.sha256((EXISTING/name).read_bytes()).hexdigest() for name in ("representation_code.zip","representation_run.pyw")}

def preservation_snapshot():
    folders = (OLD, REPO / "jev_news", REPO / "jev_model_eval")
    result = {}
    for folder in folders:
        for path in folder.rglob("*"):
            if path.is_file() and not path.name.startswith("representation_") and path.name!="REPRESENTATION_REPORT.md" and not any(name in path.parts for name in ("__pycache__", "yfinance_cache")):
                result[str(path.relative_to(REPO))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result

def prepare():
    destination = ROOT / "frozen" / "inputs.json"
    if destination.exists():
        frozen = read(destination)
        if frozen["code"] == hashes():
            verify_inputs()
            print("Existing frozen inputs verified; no membership changes.")
            return
        assert not list((ROOT / "records" / "api_cache").glob("*.json")), "No amendment after model calls"
        save(ROOT / "frozen" / "pre_call_amendment.json", {"recorded_at":now(),"previous_manifest":frozen,"reason":"Source-only preview exposed abbreviation sentence splits at Dr. and p.m.; preserve abbreviations and deprioritize financial-call boilerplate before any API requests. No price labels or forecast scores used."})
    cases = read(PRIOR / "data" / "development_cases.json") + read(PRIOR / "data" / "holdout_cases.json")
    assert len(cases) == len({case["case_id"] for case in cases}) == 150
    direct = read(PRIOR / "records" / "iteration_01_records.json")
    direct.update(read(PRIOR / "records" / "final_case_records.json")["1"])
    states = {}
    summaries = {}
    for case in cases:
        cid = case["case_id"]
        request = read(PRIOR / "records" / "api_cache" / (direct[cid]["requests"][-1] + ".json"))["request"]
        states[cid] = request["state"]
        summaries[cid] = [source_summary(article["text"],article["title"]) for article in states[cid]["articles"]]
    questions = read(PRIOR / "records" / "proposals" / "02.json")["questions"]
    outcomes = read(PRIOR / "data" / "development_outcomes.json")
    outcomes.update(read(PRIOR / "data" / "holdout_outcomes.json"))
    assert set(outcomes) == set(states)
    data = {"cases.json":cases, "raw_states.json":states, "summaries.json":summaries, "questions.json":questions, "outcomes.json":outcomes, "saved_direct_predictions.json":{cid:value["probabilities"] for cid,value in direct.items()}}
    for name, value in data.items():
        save(ROOT / "data" / name, value)
    save(ROOT / "frozen" / "previous_files.json", preservation_snapshot())
    save(ROOT / "frozen" / "environment.json", {name:importlib.metadata.version(name) for name in ("numpy","pandas","scikit-learn","requests")})
    frozen = {"frozen_at":now(), "protocol":digest(read(ROOT / "protocol.json")), "data":{name:digest(value) for name,value in data.items()}, "code":hashes(), "cases":150, "outcomes_previously_seen":True}
    save(destination, frozen)
    for cid in list(states)[:3] + ["AAPL-2025-02-21-216bbb1456"]:
        save(ROOT / "examples" / (cid + ".json"), {"raw_json":states[cid], "percent_descriptions":numeric_state(states[cid]), "summarized_prose":prose_state(states[cid],summaries[cid])})
    lengths = [value["summary_words"] for group in summaries.values() for value in group]
    print("FROZEN",150,"cases; summary words min/mean/max",min(lengths),round(float(np.mean(lengths)),1),max(lengths),flush=True)

def verify_inputs():
    value = read(ROOT / "frozen" / "inputs.json")
    assert value["protocol"] == digest(read(ROOT / "protocol.json"))
    assert value["code"] == hashes(), "Code changed after freeze"
    for name, expected in value["data"].items():
        assert digest(read(ROOT / "data" / name)) == expected, name
    return value

def raw_prior(questions, response):
    return {name:{"question":question["instructions"], "criteria":question.get("criteria"), "answer":response["answers"][name]} for name,question in questions.items()}

def api(state, questions):
    request = {"model":read(ROOT / "protocol.json")["model"], "state":state, "questions":questions}
    key = digest(request)
    cache = ROOT / "records" / "api_cache" / (key + ".json")
    prior = PRIOR / "records" / "api_cache" / cache.name
    if not cache.exists() and prior.exists():
        cached = read(prior)
        assert cached["request"] == request
        cache.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(prior,cache)
        save(ROOT / "records" / "reused" / cache.name, {"source":str(prior), "request_sha256":key})
    return strategy.call_jev(state, questions)

def one_case(cid, arm, states, summaries, original_questions):
    path = ROOT / "records" / "cases" / arm / (cid + ".json")
    original = states[cid]
    questions = original_questions if arm == "raw_json" else {stage:rate_questions(value) for stage,value in original_questions.items()}
    signature = digest({"arm":arm,"state":original,"summary":summaries[cid],"questions":questions})
    if path.exists():
        cached = read(path)
        assert cached["input_sha256"] == signature
        return cached
    value = {"case_id":cid, "arm":arm, "input_sha256":signature, "status":"failed", "requests":[], "probabilities":None}
    if arm == "raw_json":
        state = copy.deepcopy(original)
    elif arm == "percent_descriptions":
        state = numeric_state(original)
    else:
        state = prose_state(original,summaries[cid])
    first, key = api(state,questions["business"])
    value["requests"].append(key)
    if first is not None:
        value["assessments"] = first["answers"]
        if arm == "raw_json":
            state["prior_assessments"] = raw_prior(questions["business"],first)
        elif arm == "percent_descriptions":
            state["prior_assessments"] = described_prior(questions["business"],first)
        else:
            state = prose_state(original,summaries[cid],first)
        second, key = api(state,questions["forecast"])
        value["requests"].append(key)
        if second is not None:
            value.update(status="ok",probabilities=second["answers"]["forecast"]["probabilities"])
    value["completed_at"] = now()
    save(path,value)
    return value

def run(smoke=False):
    verify_inputs()
    if (ROOT / "records" / "scores.json").exists():
        raise ValueError("Comparison completed; no further prediction round")
    cases = read(ROOT / "data" / "cases.json")
    states = read(ROOT / "data" / "raw_states.json")
    summaries = read(ROOT / "data" / "summaries.json")
    questions = read(ROOT / "data" / "questions.json")
    selected = sorted((case for case in cases if case["split"] == "train"),key=lambda case:case["decision_time"])[:3] if smoke else cases
    for arm in ARMS:
        print("START",arm,len(selected),"cases",flush=True)
        values = {}
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = [pool.submit(one_case,case["case_id"],arm,states,summaries,questions) for case in selected]
            for count, future in enumerate(as_completed(futures),1):
                value = future.result()
                values[value["case_id"]] = value
                if count % 30 == 0 or count == len(selected):
                    print("PROGRESS",arm,count,"/",len(selected),"valid",sum(value["status"]=="ok" for value in values.values()),flush=True)
        if not smoke:
            save(ROOT / "records" / (arm+"_records.json"),values)
    if smoke:
        save(ROOT / "records" / "smoke.json", {"completed_at":now(),"ids":[case["case_id"] for case in selected],"scope":"transport/schema only; no outcomes inspected", "passed":all(read(ROOT / "records" / "cases" / arm / (case["case_id"]+".json"))["status"]=="ok" for arm in ARMS for case in selected)})
        print("Smoke complete; saved responses will be reused.",flush=True)
        return
    # Only the evaluator receives outcomes. All renderers operate on allowlisted inputs.
    outcomes = read(ROOT / "data" / "outcomes.json")
    all_ids = [case["case_id"] for case in cases]
    groups = {"all150":all_ids}
    groups.update({split:[case["case_id"] for case in cases if case["split"] == split] for split in sorted({case["split"] for case in cases})})
    predictions = {arm:{cid:value["probabilities"] for cid,value in read(ROOT / "records" / (arm+"_records.json")).items()} for arm in ARMS}
    predictions["saved_single_call"] = read(ROOT / "data" / "saved_direct_predictions.json")
    predictions["market_only"] = {cid:state["base_forecast"]["probabilities"] for cid,state in states.items()}
    predictions["training_prior"] = {cid:read(OLD / "frozen" / "training_prior.json") for cid in all_ids}
    for label in evaluate.LABELS:
        predictions["always_"+label] = {cid:{name:float(name==label) for name in evaluate.LABELS} for cid in all_ids}
    scores = {arm:{split:score(ids,values,outcomes) for split,ids in groups.items()} for arm,values in predictions.items()}
    save(ROOT / "records" / "scores.json", {"completed_at":now(),"scores":scores})
    for arm in ARMS:
        metric = scores[arm]["all150"]
        print("RESULT",arm,{key:metric[key] for key in ("correct","labeled","full_coverage_accuracy","balanced_accuracy","brier","forecast_coverage")},flush=True)

def score(ids,predictions,outcomes):
    result = evaluate.score(ids,predictions,outcomes)
    result["correct"] = sum(row["correct"] is True for row in result["rows"])
    result["full_coverage_accuracy"] = result["correct"]/result["labeled"] if result["labeled"] else 0.
    return result

def status():
    for arm in ARMS:
        values = [read(path) for path in (ROOT / "records" / "cases" / arm).glob("*.json")]
        print(arm,len(values),"completed;",sum(value["status"]=="ok" for value in values),"valid")

def verify():
    verify_inputs()
    expected = read(ROOT / "frozen" / "previous_files.json")
    actual = preservation_snapshot()
    changed = [name for name,value in expected.items() if actual.get(name)!=value]
    assert not changed,changed
    forbidden = {"label","labels","outcome","outcomes","actual","future_return","entry_open","exit_close"}
    def check(value):
        if isinstance(value,dict):
            assert not (set(value)&forbidden),set(value)&forbidden
            for child in value.values():
                check(child)
        elif isinstance(value,list):
            for child in value:
                check(child)
    attempts = rejected = failed = 0
    tokens = {}
    total = 0
    for path in (ROOT / "records" / "api_cache").glob("*.json"):
        value = read(path)
        assert digest(value["request"])==path.stem
        check(value["request"]["state"])
        total += 1
        attempts += len(value["attempts"])
        rejected += sum(attempt.get("status")=="rejected" for attempt in value["attempts"])
        failed += value["status"]!="ok"
        if value["status"]=="ok":
            strategy.validate(value["response"],value["request"]["questions"])
            tokens[path.stem] = value["response"]["usage"]["input_tokens"]
    if (ROOT / "records" / "scores.json").exists():
        outcomes = read(ROOT / "data" / "outcomes.json")
        cases = read(ROOT / "data" / "cases.json")
        saved = read(ROOT / "records" / "scores.json")["scores"]
        for arm in ARMS:
            records = read(ROOT / "records" / (arm+"_records.json"))
            assert len(records)==150
            replay = score([case["case_id"] for case in cases],{cid:value["probabilities"] for cid,value in records.items()},outcomes)
            assert replay==saved[arm]["all150"]
        original = read(PRIOR / "records" / "iteration_02_records.json")
        raw = read(ROOT / "records" / "raw_json_records.json")
        assert all(raw[cid]["probabilities"]==value["probabilities"] for cid,value in original.items())
    result = {"verified_at":now(),"passed":True,"earlier_files_checked":len(expected),"changed":changed,"unique_api_requests":total,"reused_requests":len(list((ROOT / "records" / "reused").glob("*.json"))),"attempts_in_saved_records":attempts,"rejected_attempts":rejected,"exhausted_requests":failed,"model":"jev-1.13.0","request_outcome_field_violations":0}
    save(ROOT / "records" / "verification.json",result)
    print("VERIFIED",result,flush=True)
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command",choices=["prepare","test","smoke","run","report","verify","status"])
    args = parser.parse_args()
    if args.command == "test":
        import unittest
        from . import test_representation
        result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(test_representation))
        raise SystemExit(0 if result.wasSuccessful() else 1)
    if args.command == "report":
        from .report import report
        return report()
    if args.command == "smoke":
        return run(smoke=True)
    return globals()[args.command]()

if __name__ == "__main__":
    main()
