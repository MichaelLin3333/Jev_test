"""Deterministic presentation only: no outcomes, new facts or model fitting."""
import copy
import re

LABELS = ("up", "flat", "down")
MARKET_DESCRIPTIONS = {
    "stock_return_1": "The stock's closing-price change over the last completed session",
    "stock_return_5": "The stock's closing-price change over the last five completed sessions",
    "stock_return_20": "The stock's closing-price change over the last twenty completed sessions",
    "stock_volatility_20": "The stock's daily-return volatility estimated from twenty completed sessions",
    "spy_return_1": "The SPY broad-market closing-price change over the last completed session",
    "spy_return_5": "The SPY broad-market closing-price change over the last five completed sessions",
    "spy_return_20": "The SPY broad-market closing-price change over the last twenty completed sessions",
    "spy_volatility_20": "SPY's daily-return volatility estimated from twenty completed sessions",
    "relative_return_5": "The stock's five-session return minus SPY's five-session return",
    "relative_return_20": "The stock's twenty-session return minus SPY's twenty-session return",
}
PURPOSES = {
    "relevance": "a specific direct, commercial or policy connection to the target",
    "economic_event": "a substantive economic action rather than publicity or a calendar notice",
    "materiality": "a supported incremental amount relative to a comparable numerical baseline",
}
BOILERPLATE = re.compile(r"forward.looking statements|safe harbor|media contact|press contact|investor relations contact|copyright|all rights reserved|actual results (?:may|could) differ", re.I)

def percent(value, digits=2):
    return "not supplied" if value is None else f"{100*value:.{digits}f}%"

def movement(value):
    if value is None:
        return "not supplied"
    if value > 0:
        return f"rose {percent(value)}"
    if value < 0:
        return f"fell {percent(abs(value))}"
    return "was unchanged (0.00%)"

def market_sentence(name, value):
    description = MARKET_DESCRIPTIONS[name]
    if value is None:
        return description + " is not supplied."
    if "relative" in name:
        relation = "outperformed" if value > 0 else "underperformed" if value < 0 else "matched"
        horizon = 5 if name.endswith("_5") else 20
        return f"Over {horizon} completed sessions the stock {relation} SPY by {100*abs(value):.2f} percentage points (stock return minus SPY return)."
    if "volatility" in name:
        return f"{description} is {percent(value)}; this measures variability, not expected appreciation."
    return f"{description}: {movement(value)}."

def rate_questions(questions):
    """Only replace equivalent decimal target boundaries with explicit units."""
    value = copy.deepcopy(questions)
    for question in value.values():
        for field in ("instructions", "criteria"):
            content = question.get(field)
            def convert(text):
                return text.replace("between -0.01 and +0.01", "between -1.00% and +1.00% inclusive").replace("exceeds +0.01", "exceeds +1.00%").replace("below -0.01", "below -1.00%")
            if isinstance(content, str):
                question[field] = convert(content)
            elif isinstance(content, dict):
                question[field] = {key:convert(text) if isinstance(text, str) else text for key,text in content.items()}
    return value

def numeric_state(original):
    state = copy.deepcopy(original)
    for field in ("pre_cutoff_market",):
        state[field] = {name:market_sentence(name,value) for name,value in original[field].items()}
    state["market_context"]["data"] = copy.deepcopy(state["pre_cutoff_market"])
    state["market_context"]["units"] = "Percentages and percentage-point differences, as explicitly described."
    state["base_forecast"]["probabilities"] = {label:percent(value,4)+f" model probability of {label}; this is a forecast reference, not an observed outcome" for label,value in original["base_forecast"]["probabilities"].items()}
    state["forecast_target"]["neutral_band"] = "1.00% half-band; flat includes both -1.00% and +1.00%."
    scale = state.get("volatility_scale")
    if scale:
        scale["five_session_one_sigma_reference"] = percent(original["volatility_scale"]["five_session_one_sigma_reference"])+" five-session variability reference, not an expected return"
        ratio = original["volatility_scale"]["flat_half_band_divided_by_sigma"]
        scale["flat_half_band_divided_by_sigma"] = percent(ratio)+" of the volatility reference; this is a scale ratio, not a price return"
    return state

def described_prior(questions, response):
    result = {}
    for name, question in questions.items():
        answer = copy.deepcopy(response["answers"][name])
        if answer["type"] == "noul":
            answer["noul"] = percent(answer["noul"],4)+" assessed probability of yes to this question; not a stock-return probability"
        else:
            answer["probabilities"] = {label:percent(value,4)+f" assessed probability of {label}" for label,value in answer["probabilities"].items()}
            answer["confidence"] = percent(answer["confidence"],4)+" model-reported confidence in this business judgment; not a stock-return probability"
        result[name] = {"question":question["instructions"], "criteria":question.get("criteria"), "answer":answer}
    return result

def source_summary(text, title):
    """Whole-sentence extractive summary with auditable source spans."""
    normalized = re.sub(r"[ \t]+", " ", text).strip()
    candidates = []
    offset = 0
    # Paragraph boundaries also delimit headings and lists; decimals stay intact.
    for paragraph in re.split(r"\n\s*\n", normalized):
        protected = re.sub(r"\b(?:Dr|Mr|Mrs|Ms|Prof|Inc|Corp|Ltd|Co|U\.S|U\.K|a\.m|p\.m)\.",lambda match:match.group().replace(".","\ufff0"),paragraph,flags=re.I)
        for sentence in re.split(r"(?<=[.!?])\s+(?=[A-Z\"“(])", protected):
            sentence = sentence.replace("\ufff0",".").strip()
            if len(sentence) < 35 or BOILERPLATE.search(sentence):
                continue
            candidates.append({"index":offset, "text":sentence})
            offset += 1
    if not candidates:
        candidates = [{"index":0, "text":normalized}]
    headline_words = {word for word in re.findall(r"[a-z]{4,}", title.lower()) if word not in {"with","from","that","this","more","news","announces","introduces"}}
    def score(row):
        sentence = row["text"]
        words = set(re.findall(r"[a-z]{4,}", sentence.lower()))
        calendar_penalty = 8*bool(re.search(r"teleconference|conference call|investor relations|webcast",sentence,re.I))
        return (5 if row["index"] == 0 else 0) + 2*len(headline_words & words) + 3*bool(re.search(r"\d", sentence)) + 4*bool(re.search(r"revenue|profit|margin|cash|billion|million|guidance|agreement|license|restriction|acquir|investment|repurchase|launch|available|will|expects", sentence, re.I)) - calendar_penalty
    selected = [candidates[0]]
    words = len(candidates[0]["text"].split())
    for row in sorted(candidates[1:], key=lambda row:(-score(row),row["index"])):
        count = len(row["text"].split())
        if len(selected) >= 5:
            break
        if words + count <= 200:
            selected.append(row)
            words += count
    selected.sort(key=lambda row:row["index"])
    summary = " ".join(row["text"] for row in selected)
    numbers = lambda value:set(re.findall(r"[-+]?\d[\d,.]*(?:%|\s*(?:billion|million|trillion))?", value))
    return {"text":summary, "selected_sentences":selected, "method":"deterministic source-sentence condensation; no generative facts", "original_words":len(text.split()), "summary_words":len(summary.split()), "omitted_numeric_tokens":sorted(numbers(text)-numbers(summary))}

def prose_state(original, summaries, previous=None):
    company = original["company"]
    lines = [f"Target company: {company['name']} ({company['ticker']}). {company['profile']}", f"Focal announcement: {original['focal_event']}.", f"Decision cutoff: {original['decision_time']}. Use only information available before this cutoff."]
    for article, summary in zip(original["articles"], summaries):
        lines += [f"Source: {article['title']}. Published date: {article['publication_date']}. URL: {article['url']}.", "Condensed source passage, selected from the supplied excerpt; other details are omitted: " + summary["text"]]
    lines += ["Historical limitation: the exact historical article version is unverified; publication date does not establish that today's text existed then.", "Pre-announcement expectations: " + original["expectations"]["details"], "Company financial baselines: none supplied." if not original["company_baselines"] else "Supplied company baselines: " + str(original["company_baselines"]), "Incremental financial magnitude inputs: not supplied." if original["magnitude_inputs"] is None else "Magnitude inputs: " + str(original["magnitude_inputs"]), "Observed market context, using completed sessions before the cutoff:"]
    lines += [market_sentence(name,value) for name,value in original["pre_cutoff_market"].items()]
    reference = original["base_forecast"]["probabilities"]
    lines += ["A previously fitted, training-only market model supplied these reference probabilities: " + "; ".join(f"{label} {percent(reference[label],4)}" for label in LABELS) + ". They are predictions, not facts about what happened later."]
    if original.get("volatility_scale"):
        lines += ["The code-computed five-session volatility reference is " + percent(original["volatility_scale"]["five_session_one_sigma_reference"]) + ". It measures a variability scale, not an expected return or a guarantee of the flat probability."]
    lines += ["Prediction target: buy at the first regular-session opening price after the cutoff; compare with the fifth regular-session closing price, counting entry as session one. Predict raw price return. Up means above +1.00%; flat means -1.00% through +1.00% inclusive; down means below -1.00%. The initial pre-entry price reaction is outside the target.", "Do not infer analyst consensus, corporate cash spending, incremental sales, or a news-attributed price reaction when it is not supplied."]
    if previous is not None:
        lines += ["Earlier Jev judgments follow. These are uncertain model assessments, not verified facts. Unknown means missing evidence, not no effect and not a flat price forecast."]
        for name, answer in previous["answers"].items():
            if answer["type"] == "noul":
                lines.append(f"For {PURPOSES[name]}, earlier Jev assigned yes {percent(answer['noul'],4)} and no {percent(1-answer['noul'],4)}.")
            else:
                distribution = "; ".join(f"{label} {percent(value,4)}" for label,value in answer["probabilities"].items())
                lines.append(f"For the target's {name} assessment, earlier Jev selected {answer['choice']}. Its complete distribution was {distribution}. Its separately reported confidence was {percent(answer['confidence'],4)}. This is a business assessment, not a return forecast.")
    return "\n\n".join(lines)
